from pydantic import BaseModel
from datetime import datetime


class UserRegister(BaseModel):
    name: str
    age: int
    gender: str
    email: str | None = None
    allergies: str | None = None
    conditions: str | None = None


class UserUpdate(BaseModel):
    name: str | None = None
    age: int | None = None
    gender: str | None = None
    email: str | None = None
    location_text: str | None = None
    location_lat: float | None = None
    location_lng: float | None = None
    role: str | None = None
    push_token: str | None = None
    allergies: str | None = None
    conditions: str | None = None


class UserOut(BaseModel):
    id: int
    phone: str | None
    google_id: str | None = None
    name: str | None
    age: int | None
    gender: str | None
    email: str | None
    location_text: str | None = None
    location_lat: float | None = None
    location_lng: float | None = None
    role: str
    push_token: str | None = None
    profile_picture: str | None = None
    allergies: str | None
    conditions: str | None
    is_verified: bool
    is_registered: bool
    created_at: datetime | None

    class Config:
        from_attributes = True


class UserListItemOut(BaseModel):
    id: int
    name: str | None
    email: str | None
    role: str

    class Config:
        from_attributes = True
